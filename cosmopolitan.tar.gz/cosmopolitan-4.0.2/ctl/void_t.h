// -*-mode:c++;indent-tabs-mode:nil;c-basic-offset:4;tab-width:8;coding:utf-8-*-
// vi: set et ft=cpp ts=4 sts=4 sw=4 fenc=utf-8 :vi
#ifndef CTL_VOID_T_H_
#define CTL_VOID_T_H_

namespace ctl {

template<typename... Ts>
using void_t = void;

} // namespace ctl

#endif // CTL_VOID_T_H_
