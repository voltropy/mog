#ifndef COSMOPOLITAN_DSP_SCALE_CDECIMATE2XUINT8X8_H_
#define COSMOPOLITAN_DSP_SCALE_CDECIMATE2XUINT8X8_H_
COSMOPOLITAN_C_START_

void *cDecimate2xUint8x8(unsigned long n, unsigned char[n],
                         const signed char[8]);

COSMOPOLITAN_C_END_
#endif /* COSMOPOLITAN_DSP_SCALE_CDECIMATE2XUINT8X8_H_ */
