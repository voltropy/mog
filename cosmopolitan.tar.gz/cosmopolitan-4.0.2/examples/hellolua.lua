print(string.format("2 + 3 = %g", NativeAdd(2, 3)))
