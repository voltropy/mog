#include "examples/package/lib/myprint.h"

int main(int argc, char *argv[]) {
  MyPrint("welcome to your package\n");
  return 0;
}
